package com.dailycodework.demo.model;

import jakarta.persistence.*;
//import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
public class Question {

	@Id@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
//	@NotBlank
	
	private String question;
//	@NotBlank
	
	private String subject;
//	@NotBlank
	
	private String questionType;
//	@NotBlank
	
	@ElementCollection
	private List<String> choices;
	public Object getQuestion() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setQuestion(Object question2) {
		// TODO Auto-generated method stub
		
	}
	public Object getChoices() {
		// TODO Auto-generated method stub
		return null;
	}
	public Object getCorrectAnswers() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setChoices(Object choices2) {
		// TODO Auto-generated method stub
		
	}
	public void setCorrectAnswers(Object correctAnswers) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
	
	
	
}
