package com.dailycodework.demo.service;

import java.util.List;
import java.util.Optional;

import com.dailycodework.demo.model.Question;
import org.springframework.data.crossstore.ChangeSetPersister;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;

public interface IQuestionService {
	
	 void createQuestion(Question question);
	List<Question>getAllQuestion();
	Optional<Question>getQuestionById(Long id);
	List<String>getAllSubjects();
	Question updateQuestion(Long id,Question question) throws NotFoundException;
	void deleteQuestion(Long id);
	List<Question>getQuestionForUser(Integer numOfQuestions,String subject);

}
